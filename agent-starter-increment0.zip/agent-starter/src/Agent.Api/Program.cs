// ============================================================================
// BestPracticesAgent — Incrément 0 + première tranche de l'incrément 1
// Objectif de cette tranche : prouver, sur un poste réel, que :
//   1) l'agent écoute en loopback et répond au badge "Agent connecté" ;
//   2) l'appairage cross-origin fonctionne depuis le prototype PR Review ;
//   3) la connexion TOM au modèle ouvert dans Power BI Desktop fonctionne.
// Le moteur de règles, le planner, le dry-run et l'exécuteur viennent après —
// une fois ces trois points validés sur ton parc réel.
// ============================================================================

using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AnalysisServices.Tabular;

var builder = WebApplication.CreateBuilder(args);

// ----------------------------------------------------------------------
// Arguments transmis par Power BI Desktop via l'outil externe :
//   BestPracticesAgent.exe --server "localhost:XXXXX" --database "GUID" --port 0
// --port 0 = port éphémère aléatoire choisi par l'OS (recommandé : jamais fixe).
// ----------------------------------------------------------------------
string? serverArg = GetArg(args, "--server");
string? databaseArg = GetArg(args, "--database");
int requestedPort = int.TryParse(GetArg(args, "--port"), out var p) ? p : 0;

static string? GetArg(string[] args, string name)
{
    var i = Array.IndexOf(args, name);
    return i >= 0 && i + 1 < args.Length ? args[i + 1] : null;
}

// ----------------------------------------------------------------------
// Écoute STRICTEMENT en loopback. Port 0 = éphémère, choisi par l'OS.
// ----------------------------------------------------------------------
builder.WebHost.ConfigureKestrel(options =>
{
    options.Listen(System.Net.IPAddress.Loopback, requestedPort);
});

var app = builder.Build();

// ----------------------------------------------------------------------
// État en mémoire (process unique, pas de base de données à ce stade).
// ----------------------------------------------------------------------
var sessions = new ConcurrentDictionary<string, AgentSession>();
var pairings = new ConcurrentDictionary<string, PairingRequest>();
var tokens = new ConcurrentDictionary<string, string>(); // token -> origin

string agentVersion = "0.1.0-increment0";
int protocolVersion = 2;

// ----------------------------------------------------------------------
// Sécurité minimale mais non négociable dès cette tranche :
//   - Origin en liste blanche (à ajuster selon où tourne ton prototype)
//   - Host validé (protection rebinding DNS)
//   - jamais de token en query string pour des routes sensibles
// ----------------------------------------------------------------------
var allowedOrigins = new[]
{
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "null" // fichier HTML ouvert en file:// pendant les tests locaux
};

app.Use(async (ctx, next) =>
{
    var host = ctx.Request.Host.Host;
    if (host != "127.0.0.1" && host != "localhost")
    {
        ctx.Response.StatusCode = 400;
        await ctx.Response.WriteAsync("Host non autorisé.");
        return;
    }

    var origin = ctx.Request.Headers.Origin.ToString();
    if (!string.IsNullOrEmpty(origin) && !allowedOrigins.Contains(origin))
    {
        ctx.Response.StatusCode = 403;
        await ctx.Response.WriteAsync("Origine non autorisée.");
        return;
    }

    // Réponse au préflight Private Network Access (HTTPS -> 127.0.0.1).
    // Sans cet en-tête, Chrome/Edge bloquent l'appel depuis une page HTTPS.
    if (!string.IsNullOrEmpty(origin))
    {
        ctx.Response.Headers.Append("Access-Control-Allow-Origin", origin);
        ctx.Response.Headers.Append("Access-Control-Allow-Private-Network", "true");
        ctx.Response.Headers.Append("Access-Control-Allow-Headers", "Content-Type,X-Agent-Token,X-Agent-Protocol,Idempotency-Key");
        ctx.Response.Headers.Append("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    }
    if (ctx.Request.Method == "OPTIONS") { ctx.Response.StatusCode = 204; return; }

    await next();
});

// ========================================================================
// GET /api/v1/health — c'est cette route qui fait basculer le badge
// du prototype en "Agent connecté".
// ========================================================================
app.MapGet("/api/v1/health", () => Results.Json(new
{
    version = agentVersion,
    protocol = protocolVersion,
    capabilities = new[] { "tom" } // "dmv" et "pbir" arriveront aux incréments 2 et 5
}));

// ========================================================================
// Appairage — code à 6 chiffres affiché dans UNE fenêtre native de l'agent,
// jamais dans le navigateur. C'est ce qui empêche un site quelconque de
// piloter l'agent sans action physique de l'utilisateur.
// ========================================================================
app.MapPost("/api/v1/pairing/request", (HttpContext ctx, PairingBody body) =>
{
    var code = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
    var id = Guid.NewGuid().ToString("N");
    pairings[id] = new PairingRequest(code, body.Origin, DateTimeOffset.UtcNow.AddSeconds(60));

    // Incrément 0 : le code est simplement affiché dans la console de l'agent.
    // Étape suivante : une vraie fenêtre WinForms/WPF native au premier plan.
    Console.WriteLine($"[APPAIRAGE] Code à saisir dans le prototype : {code} (expire dans 60 s)");

    return Results.Json(new { pairingId = id, expiresIn = 60 });
});

app.MapPost("/api/v1/pairing/confirm", (PairingConfirmBody body) =>
{
    var match = pairings.Values.FirstOrDefault(p => p.Code == body.Code && p.ExpiresAt > DateTimeOffset.UtcNow);
    if (match is null) return Results.StatusCode(403);

    var token = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
    tokens[token] = match.Origin;
    return Results.Json(new { token });
});

// ========================================================================
// Sessions — ouvre une connexion TOM au modèle transmis par Power BI
// (%server% / %database%) ou choisi via le dialogue natif (incrément suivant).
// ========================================================================
app.MapPost("/api/v1/sessions", (HttpContext ctx) =>
{
    if (!TryAuth(ctx, tokens, out var problem)) return problem!;

    var id = "ses_" + Guid.NewGuid().ToString("N")[..12];
    sessions[id] = new AgentSession(id, serverArg, databaseArg);
    return Results.Json(new { sessionId = id, server = serverArg, database = databaseArg });
});

// ========================================================================
// Connexion TOM réelle — c'est LE test qui compte le plus sur ton parc.
// Lecture seule stricte : ITomReader n'expose aucune méthode d'écriture.
// ========================================================================
app.MapPost("/api/v1/sessions/{id}/connect", (HttpContext ctx, string id) =>
{
    if (!TryAuth(ctx, tokens, out var problem)) return problem!;
    if (!sessions.TryGetValue(id, out var session)) return Results.NotFound();

    if (string.IsNullOrEmpty(session.Server))
        return Results.BadRequest(new { code = "NO_SERVER", message = "Aucun serveur transmis. Lancez l'agent depuis Outils externes > Best Practices Agent dans Power BI Desktop." });

    try
    {
        using var server = new Server();
        server.Connect($"Data Source={session.Server}");

        var database = server.Databases.Cast<Database>().FirstOrDefault(db =>
            string.Equals(db.Name, session.Database, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(db.ID, session.Database, StringComparison.OrdinalIgnoreCase));

        if (database is null)
            return Results.NotFound(new { code = "MODEL_NOT_FOUND", message = "Modèle introuvable sur ce serveur." });

        var model = database.Model;

        // Snapshot minimal — juste de quoi prouver que la lecture TOM fonctionne
        // et remplir l'écran "modèle analysé" du prototype. Le snapshot complet
        // (Merkle, DMV, graphe de dépendances) arrive à l'incrément suivant.
        var summary = new
        {
            databaseId = database.ID,
            databaseName = database.Name,
            compatibilityLevel = database.CompatibilityLevel,
            tables = model.Tables.Count,
            columns = model.Tables.Cast<Table>().Sum(t => t.Columns.Count),
            measures = model.Tables.Cast<Table>().Sum(t => t.Measures.Count),
            relationships = model.Relationships.Count,
            discourageImplicitMeasures = model.DiscourageImplicitMeasures
        };

        server.Disconnect();
        return Results.Json(summary);
    }
    catch (Exception ex)
    {
        // Ne jamais renvoyer la stack complète au navigateur : message sobre,
        // détail complet uniquement dans le journal local de l'agent.
        Console.Error.WriteLine(ex);
        return Results.Problem(title: "Échec de connexion TOM", detail: ex.Message, statusCode: 502);
    }
});

app.Run();

// ----------------------------------------------------------------------
// Aides
// ----------------------------------------------------------------------
static bool TryAuth(HttpContext ctx, ConcurrentDictionary<string, string> tokens, out IResult? problem)
{
    var token = ctx.Request.Headers["X-Agent-Token"].ToString();
    if (string.IsNullOrEmpty(token) || !tokens.ContainsKey(token))
    {
        problem = Results.StatusCode(401);
        return false;
    }
    problem = null;
    return true;
}

record AgentSession(string Id, string? Server, string? Database);
record PairingRequest(string Code, string Origin, DateTimeOffset ExpiresAt);
record PairingBody(string Origin);
record PairingConfirmBody(string Code);
