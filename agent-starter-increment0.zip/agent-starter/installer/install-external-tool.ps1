param(
    [Parameter(Mandatory = $true)]
    [string]$PublishedAgentDirectory
)

$ErrorActionPreference = "Stop"

$toolsDir = Join-Path $env:PROGRAMDATA "Microsoft\Power BI Desktop\External Tools"
New-Item -ItemType Directory -Force -Path $toolsDir | Out-Null

$targetExeDir = Join-Path $env:APPDATA "BestPracticesAgent"
New-Item -ItemType Directory -Force -Path $targetExeDir | Out-Null

Copy-Item -Path (Join-Path $PublishedAgentDirectory "*") -Destination $targetExeDir -Recurse -Force

$manifestSource = Join-Path $PSScriptRoot "BestPracticesAgent.pbitool.json"
Copy-Item -Path $manifestSource -Destination (Join-Path $toolsDir "BestPracticesAgent.pbitool.json") -Force

Write-Host "Outil externe installé. Redémarrez Power BI Desktop, ouvrez un rapport, puis :"
Write-Host "  Outils externes > Best Practices Agent"
