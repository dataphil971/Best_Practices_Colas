# Best Practices Agent — Incrément 0

Tranche minimale : `/health`, appairage, connexion TOM réelle en lecture seule.
Objectif : valider sur ton poste que la chaîne complète navigateur ↔ agent ↔
Power BI Desktop fonctionne, avant d'investir dans le moteur de règles.

## Prérequis

- Windows 10/11
- [.NET 8 SDK](https://dotnet.microsoft.com/download)
- Power BI Desktop installé
- Le prototype `PR_Review_PowerBI_avec_agent_v2.html`

## 1. Lancer en mode développeur (le plus rapide pour tester)

```powershell
cd src\Agent.Api
dotnet restore
dotnet run -- --server "localhost:0" --database "" --port 27841
```

`--server`/`--database` vides fonctionnent pour tester `/health` et l'appairage.
Pour tester la vraie connexion TOM, il faut les valeurs réelles — voir étape 3.

Ouvre le prototype dans le navigateur, clique sur le bouton flottant : le badge
doit passer de **Démo** à **Agent connecté**.

## 2. Trouver server/database sans passer par l'outil externe (test rapide)

Pendant que Power BI Desktop a un rapport ouvert :

```powershell
Get-Process msmdsrv.exe -ErrorAction SilentlyContinue
netstat -ano | findstr LISTENING | findstr <PID_du_process_ci-dessus>
```

Le port trouvé donne `localhost:<port>`. Le nom de la base (GUID) s'obtient en
te connectant avec DAX Studio ou SSMS et en listant les bases. **Ceci est une
béquille de développement uniquement** — en usage réel, ces valeurs viennent de
`%server%`/`%database%` transmis par Power BI via l'outil externe (étape 3),
comme prévu dans `docs/RISK_POLICY.md` du starter d'origine.

## 3. Installer comme véritable outil externe

```powershell
dotnet publish src\Agent.Api -c Release -r win-x64 --self-contained true `
  /p:PublishSingleFile=true -o publish

powershell -ExecutionPolicy Bypass -File installer\install-external-tool.ps1 `
  -PublishedAgentDirectory "$PWD\publish"
```

Redémarre Power BI Desktop, ouvre un rapport, puis :
**Outils externes > Best Practices Agent**.

Power BI lance alors l'agent avec le vrai `--server` et le vrai `--database`.
Vérifie dans le prototype que l'appel à `/api/v1/sessions/{id}/connect`
renvoie bien le nombre de tables/colonnes/mesures de ton modèle réel.

## 4. Ce que cette tranche prouve — et ce qu'il reste à faire

| Validé par cet incrément | Reste à construire |
|---|---|
| Le badge passe en "Agent connecté" | Snapshot TMSL complet + empreinte Merkle |
| L'appairage fonctionne cross-origin | Graphe de dépendances (DMV) |
| Preflight Private Network Access géré | Moteur de règles (SUM001, HID001…) |
| Connexion TOM réelle en lecture | Planner, dry-run, exécuteur, rollback |
| Aucune écriture possible (pas de setter exposé) | Journal chaîné, sauvegarde TMSL |

Voir `ARCHITECTURE_v2.md` section 16 pour les points à vérifier sur ton parc
avant d'aller plus loin (LineageTag, transactions TOM, versions de Desktop).

## Sécurité de cette tranche

- écoute strictement en loopback (`127.0.0.1`) ;
- `Origin` en liste blanche dans `Program.cs` — **ajuste `allowedOrigins`**
  selon où tu ouvres réellement le prototype (fichier local = `null`,
  futur frontend React = `http://localhost:5173`) ;
- `Host` validé pour bloquer le rebinding DNS ;
- token d'appairage à usage unique, jamais en query string ;
- aucune méthode d'écriture TOM exposée à ce stade — impossible d'écrire
  dans le modèle même par erreur.
